const buttons = document.querySelectorAll(".mapbtn");

for (const button of buttons) {
  button.remove();
}